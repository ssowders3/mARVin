var classArActionStallRecover =
[
    [ "State", "classArActionStallRecover.html#aaee8529f205da0f5399c5a75a23d4294", [
      [ "STATE_NOTHING", "classArActionStallRecover.html#aaee8529f205da0f5399c5a75a23d4294a4f06854175ad861337a5af4b6750cb75", null ],
      [ "STATE_GOING", "classArActionStallRecover.html#aaee8529f205da0f5399c5a75a23d4294a47cbdf701bbc56d213549c99d3905bca", null ]
    ] ],
    [ "What", "classArActionStallRecover.html#a961898714f13a6d9e286d540c4cbe426", [
      [ "BACK", "classArActionStallRecover.html#a961898714f13a6d9e286d540c4cbe426a1ffb262a5ed4e8bb76a52f286145ec1f", null ],
      [ "FORWARD", "classArActionStallRecover.html#a961898714f13a6d9e286d540c4cbe426a720ceea86abd7b924fce43e034816221", null ],
      [ "TURN", "classArActionStallRecover.html#a961898714f13a6d9e286d540c4cbe426acd22907c55c4fe5f19a814ad8535d5c3", null ],
      [ "TURN_LEFT", "classArActionStallRecover.html#a961898714f13a6d9e286d540c4cbe426a7dca05f5eca54a554ce0f03e3a29e11c", null ],
      [ "TURN_RIGHT", "classArActionStallRecover.html#a961898714f13a6d9e286d540c4cbe426a21069c09c1fd8a58563fa39f63bc7314", null ],
      [ "MOVEMASK", "classArActionStallRecover.html#a961898714f13a6d9e286d540c4cbe426a8621daf36ffae51ea0bfb2071f47b51e", null ],
      [ "TURNMASK", "classArActionStallRecover.html#a961898714f13a6d9e286d540c4cbe426a1b24d023b9fbd83ea2518656f215d616", null ]
    ] ],
    [ "ArActionStallRecover", "classArActionStallRecover.html#ad557c66045527426b193c433bfbe5215", null ],
    [ "~ArActionStallRecover", "classArActionStallRecover.html#ab78548506683e33d86bcb567ff133993", null ],
    [ "activate", "classArActionStallRecover.html#abda3ab5128c6bbf87aa071c62c7c76a2", null ],
    [ "addSequence", "classArActionStallRecover.html#a50d159fd006318e7225306cf4734b160", null ],
    [ "addToConfig", "classArActionStallRecover.html#a4b8af84b92d5102dd90922c019af094a", null ],
    [ "doit", "classArActionStallRecover.html#a0756f7d6cf2df800c2ab4226ee266d02", null ],
    [ "fire", "classArActionStallRecover.html#a0b60112cfa0e4358d451c2fe62d1db55", null ],
    [ "getDesired", "classArActionStallRecover.html#ad9f0b3ef7a671efb56173bbb15cdc87e", null ],
    [ "getDesired", "classArActionStallRecover.html#a44040a73e3f98835592b68a6f452fc01", null ],
    [ "myActionDesired", "classArActionStallRecover.html#ad7f0deeda91eebd79d51247fc933d977", null ],
    [ "myCount", "classArActionStallRecover.html#a1cef7be760b1cb7b6d64b9839510b22b", null ],
    [ "myCyclesToMove", "classArActionStallRecover.html#a1de486fda09f61d45d72048240a48411", null ],
    [ "myCyclesToTurn", "classArActionStallRecover.html#ae593879b0ac70bf396e8218909e128f4", null ],
    [ "myDegreesToTurn", "classArActionStallRecover.html#a8bd07c73d79d5490840d74c720233605", null ],
    [ "myDesiredHeading", "classArActionStallRecover.html#a36d21d54c0a72b57fc4030ad68360f81", null ],
    [ "myDoing", "classArActionStallRecover.html#a95101d736c3b2e3a78df1d34bca02bfe", null ],
    [ "myEnabled", "classArActionStallRecover.html#a31b17aa3556f523d99ca770acf0b8164", null ],
    [ "myLastFired", "classArActionStallRecover.html#a09756aace35867559fa777b1f4a90b48", null ],
    [ "myObstacleDistance", "classArActionStallRecover.html#a7e35d54c583e31bc127a901091c88699", null ],
    [ "myResolver", "classArActionStallRecover.html#a85375e97c41d5d6de01a05b0dd416e70", null ],
    [ "mySequence", "classArActionStallRecover.html#ac172c3fb3373c224d05feac4dc43aaae", null ],
    [ "mySequenceNum", "classArActionStallRecover.html#a15e7f00154663c758b8b60da3c2d85ad", null ],
    [ "mySequencePos", "classArActionStallRecover.html#ab34f3a2e1fd719a78964474ffce536c6", null ],
    [ "mySideStalled", "classArActionStallRecover.html#a70e7182202c22528aefe3b6651b2d729", null ],
    [ "mySpeed", "classArActionStallRecover.html#a473d89d44ce7527201898a8977f5e66e", null ],
    [ "myState", "classArActionStallRecover.html#abb359521841ec80929929a5b255d18fd", null ]
];