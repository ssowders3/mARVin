var classArColor =
[
    [ "ArColor", "classArColor.html#a29c1d55c51669ad20809f2c32435d0e5", null ],
    [ "ArColor", "classArColor.html#af66b885ddee7f4c31a7472ac6ca7330f", null ],
    [ "ArColor", "classArColor.html#a34ec4f2907b9c981485f91591105b1e0", null ],
    [ "~ArColor", "classArColor.html#a77db7beedefafa3f66c06b3d3343d22d", null ],
    [ "colorToByte4", "classArColor.html#a5668d423c870a8ba24912b9cca5fd778", null ],
    [ "getBlue", "classArColor.html#a06c86677ae07edf5bdc4a00f55510e62", null ],
    [ "getGreen", "classArColor.html#a146cf42d283d29e5d6b14d2bf0626a90", null ],
    [ "getRed", "classArColor.html#ad86cae2a580428b9f95ca99338c15359", null ],
    [ "myBlue", "classArColor.html#aa2eb4a0c9733780fb14f7057c6a514ea", null ],
    [ "myGreen", "classArColor.html#a575df71b9536046a3da54664749b9628", null ],
    [ "myRed", "classArColor.html#a08106fcdc80b807ef10f3961a2f70ef5", null ]
];