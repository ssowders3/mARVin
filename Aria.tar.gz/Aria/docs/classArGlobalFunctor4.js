var classArGlobalFunctor4 =
[
    [ "ArGlobalFunctor4", "classArGlobalFunctor4.html#a13bd24f9775bf12280c4d5a436da0642", null ],
    [ "ArGlobalFunctor4", "classArGlobalFunctor4.html#a06509fa092a8fa035f581fe93cb42bcc", null ],
    [ "ArGlobalFunctor4", "classArGlobalFunctor4.html#ac0dcf7b262cc54919f8cafa0776077bb", null ],
    [ "ArGlobalFunctor4", "classArGlobalFunctor4.html#ae5959fca81499ba24823a0a158adfd35", null ],
    [ "ArGlobalFunctor4", "classArGlobalFunctor4.html#a07d38228349a27a86a67b443fd43e792", null ],
    [ "ArGlobalFunctor4", "classArGlobalFunctor4.html#a990b0489d1cdf63564513b4124f689f1", null ],
    [ "~ArGlobalFunctor4", "classArGlobalFunctor4.html#a9941ac80e72a4197d7e2417e47cd9efc", null ],
    [ "invoke", "classArGlobalFunctor4.html#a47dbfabc9cd377c764b6097e8d9310fa", null ],
    [ "invoke", "classArGlobalFunctor4.html#ade96e03d98aea0a0dabe44d361875119", null ],
    [ "invoke", "classArGlobalFunctor4.html#a396609ba82c63fbdc419a61ffa960dcc", null ],
    [ "invoke", "classArGlobalFunctor4.html#a699f9a53959ccd161bea289403484e72", null ],
    [ "invoke", "classArGlobalFunctor4.html#a29e11314e19987de51e3be8785531934", null ],
    [ "setP1", "classArGlobalFunctor4.html#a01f585fbb76c6582f8342fba34c4e9ee", null ],
    [ "setP2", "classArGlobalFunctor4.html#a63e34a0c0c07fed3002a6e6bff1d07ee", null ],
    [ "setP3", "classArGlobalFunctor4.html#a5a13e564e17104a71834986917e5c29e", null ],
    [ "setP4", "classArGlobalFunctor4.html#af26fc1647cf64c9875c25645b582e2d9", null ],
    [ "myFunc", "classArGlobalFunctor4.html#a6c447daed6cce2f4caa70a40c6cc887f", null ],
    [ "myP1", "classArGlobalFunctor4.html#a7ae6d6f4eeade0acab74f32f6d3a7c1d", null ],
    [ "myP2", "classArGlobalFunctor4.html#af933a93e668bae5ff4f0ffa1a0f836ef", null ],
    [ "myP3", "classArGlobalFunctor4.html#a81f8511b2472bc646380cd488a16da0b", null ],
    [ "myP4", "classArGlobalFunctor4.html#a24a142a5b1a9a456f86b0391e28f268c", null ]
];