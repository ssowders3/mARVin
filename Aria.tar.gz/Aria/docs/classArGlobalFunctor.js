var classArGlobalFunctor =
[
    [ "ArGlobalFunctor", "classArGlobalFunctor.html#add466360a85f10a0164744f0e2fec78e", null ],
    [ "ArGlobalFunctor", "classArGlobalFunctor.html#a0d1a8873bf1d2a51d44636ee75b0c836", null ],
    [ "~ArGlobalFunctor", "classArGlobalFunctor.html#acd54413f3f009ac058bf7484a94b7070", null ],
    [ "invoke", "classArGlobalFunctor.html#aa6946d25fd07a25d976deeafbb53b576", null ],
    [ "myFunc", "classArGlobalFunctor.html#a1eaeff846128917c3ca6e3562f0fcc3d", null ]
];