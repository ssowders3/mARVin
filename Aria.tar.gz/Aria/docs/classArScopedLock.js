var classArScopedLock =
[
    [ "ArScopedLock", "classArScopedLock.html#a159d03a56928fc3d664c7f8022496934", null ],
    [ "~ArScopedLock", "classArScopedLock.html#a997586fd07804b26a7f05635f8f862a9", null ],
    [ "lock", "classArScopedLock.html#a61d1c66428703b2f6017d5b1b6a7bacd", null ],
    [ "unlock", "classArScopedLock.html#af419c4ff591e961de7183d1e3fd0abae", null ]
];