var classArNovatelSPAN =
[
    [ "ArNovatelSPAN", "classArNovatelSPAN.html#aba6da90782669fd84354c85371ffa353", null ],
    [ "~ArNovatelSPAN", "classArNovatelSPAN.html#aa3099f519599d76f399a3303936755a1", null ],
    [ "handleGPRMC", "classArNovatelSPAN.html#ac34405b487e4326a71b4f6812608ad06", null ],
    [ "handleINGLL", "classArNovatelSPAN.html#a11a520f69ef96e726a64e8de699609c3", null ],
    [ "initDevice", "classArNovatelSPAN.html#a20a83369688dafa83382f3cfe546a04a", null ],
    [ "GPSLatitude", "classArNovatelSPAN.html#a599a9e253b7ae019bd27b3b19690976f", null ],
    [ "GPSLongitude", "classArNovatelSPAN.html#ac576343b0448d1e36114afbe51e8a5f6", null ],
    [ "GPSTimestamp", "classArNovatelSPAN.html#a53fb09f2c3cdc46afac749f7cda879ca", null ],
    [ "GPSValidFlag", "classArNovatelSPAN.html#a1fc8a3b81827b7f69ef2b93d0141a3c1", null ],
    [ "haveGPSPosition", "classArNovatelSPAN.html#a9d4989794e43ee24209cc9f8647646a8", null ],
    [ "myGPRMCHandler", "classArNovatelSPAN.html#ac067aa3e9cbc2b47a252e180f1b7c9c7", null ],
    [ "myINGLLHandler", "classArNovatelSPAN.html#a82ad27c3f920b6a47d024e7f8220c13b", null ],
    [ "timeGotGPSPosition", "classArNovatelSPAN.html#a746035ea7dbf01c7df64109769680f3c", null ]
];