var modules =
[
    [ "Important Classes", "group__ImportantClasses.html", "group__ImportantClasses" ],
    [ "Optional Classes", "group__OptionalClasses.html", "group__OptionalClasses" ],
    [ "Predefined ArAction Classes", "group__ActionClasses.html", "group__ActionClasses" ],
    [ "Device Interface Classes", "group__DeviceClasses.html", "group__DeviceClasses" ],
    [ "Utility Classes", "group__UtilityClasses.html", "group__UtilityClasses" ],
    [ "MTX/Pioneer LX Specific Classes", "group__MTX.html", "group__MTX" ],
    [ "Easy Subset of ARIA for Beginners", "group__easy.html", "group__easy" ]
];