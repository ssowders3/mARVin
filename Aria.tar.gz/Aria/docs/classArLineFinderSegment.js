var classArLineFinderSegment =
[
    [ "ArLineFinderSegment", "classArLineFinderSegment.html#ad2010acc12a26492c0cbdfa25399c723", null ],
    [ "ArLineFinderSegment", "classArLineFinderSegment.html#ac5d9c01f249528155031d9be2fc3c120", null ],
    [ "~ArLineFinderSegment", "classArLineFinderSegment.html#acae8f09dcb4d1424e90a2b345d88b164", null ],
    [ "getAveDistFromLine", "classArLineFinderSegment.html#a3fd1e4f1f5702e9179e531690a813169", null ],
    [ "getEndPoint", "classArLineFinderSegment.html#a155ad0497f05479f15b3fa89f82aac8a", null ],
    [ "getLength", "classArLineFinderSegment.html#a4c12350563ac874268f629127f66d723", null ],
    [ "getLineAngle", "classArLineFinderSegment.html#abf81f24d7d6ef9b8d0b620124a1e53ba", null ],
    [ "getNumPoints", "classArLineFinderSegment.html#a8183d425a3432d58c726d990c982a9af", null ],
    [ "getStartPoint", "classArLineFinderSegment.html#a432858305be5c61e5104d22955f22e53", null ],
    [ "newEndPoints", "classArLineFinderSegment.html#a30ee7045e160030c6ec49669f195940f", null ],
    [ "setAveDistFromLine", "classArLineFinderSegment.html#aee6795f8a67e57a108c2df0ea9a43785", null ],
    [ "myAveDistFromLine", "classArLineFinderSegment.html#a798dccfec5e31eb0c83c64ac809ca9fd", null ],
    [ "myEndPoint", "classArLineFinderSegment.html#a80ad5e04be31a3bd525994930779711f", null ],
    [ "myLength", "classArLineFinderSegment.html#ab68729c126fedf4fd995f3b6608948cf", null ],
    [ "myLineAngle", "classArLineFinderSegment.html#a55908a42ad46973d12a44c19d57fdeba", null ],
    [ "myNumPoints", "classArLineFinderSegment.html#a65a55545aad31e9c052cd442f196d3a4", null ],
    [ "myStartPoint", "classArLineFinderSegment.html#a0e3275a3b1c6677db233f9f04287417f", null ]
];