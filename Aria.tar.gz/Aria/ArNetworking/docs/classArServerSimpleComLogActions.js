var classArServerSimpleComLogActions =
[
    [ "ArServerSimpleComLogActions", "classArServerSimpleComLogActions.html#a7ad350f7e0c87e89fde1a51a6527bce4", null ],
    [ "logActions", "classArServerSimpleComLogActions.html#a4c31274c95fcb028649df7a914c66153", null ]
];