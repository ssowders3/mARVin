var structArMapChanger_1_1ClientChangeInfo =
[
    [ "ClientChangeInfo", "structArMapChanger_1_1ClientChangeInfo.html#a99e542b23c62fc532cc3287bb7912cf6", null ],
    [ "ClientChangeInfo", "structArMapChanger_1_1ClientChangeInfo.html#a0bf8ff496b8521b438854f35e8679c33", null ],
    [ "~ClientChangeInfo", "structArMapChanger_1_1ClientChangeInfo.html#a8b6cc12262b85f5fa4cc35a6182bd01d", null ],
    [ "addPacket", "structArMapChanger_1_1ClientChangeInfo.html#a33385e43a211f2d5632603e0861d206e", null ],
    [ "myClient", "structArMapChanger_1_1ClientChangeInfo.html#afe06e716e74b880957d6254883977801", null ],
    [ "myForwarder", "structArMapChanger_1_1ClientChangeInfo.html#a95be9ed68f5389a29119d81ad8eab5a2", null ],
    [ "myLastActivityTime", "structArMapChanger_1_1ClientChangeInfo.html#a56af8410e1a09d5ef844ff892d52c1e4", null ],
    [ "myPacketList", "structArMapChanger_1_1ClientChangeInfo.html#a5f6e6eb4f38231bc2823d7a445c31720", null ],
    [ "myStartTime", "structArMapChanger_1_1ClientChangeInfo.html#ab03148ce83fe28142eec3ac6c51b8e3d", null ]
];